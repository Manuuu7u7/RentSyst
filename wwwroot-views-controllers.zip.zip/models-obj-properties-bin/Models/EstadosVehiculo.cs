﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class EstadosVehiculo
{
    public int EstadoId { get; set; }

    public string NombreEstado { get; set; } = null!;

    public virtual ICollection<Vehiculo> Vehiculos { get; set; } = new List<Vehiculo>();
}
