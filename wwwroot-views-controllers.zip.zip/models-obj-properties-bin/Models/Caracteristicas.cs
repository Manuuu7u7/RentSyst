﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Caracteristicas
{
    public int CaracteristicaId { get; set; }

    public string Nombre { get; set; } = null!;

    public string? Descripcion { get; set; }

    public virtual ICollection<Vehiculo> Vehiculos { get; set; } = new List<Vehiculo>();
}
