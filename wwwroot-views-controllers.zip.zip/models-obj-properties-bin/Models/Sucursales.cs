﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Sucursales
{
    public int SucursalId { get; set; }

    public string Nombre { get; set; } = null!;

    public string Direccion { get; set; } = null!;

    public int CiudadId { get; set; }

    public string? Telefono { get; set; }

    public string? CorreoElectronico { get; set; }

    public DateOnly FechaApertura { get; set; }

    public bool Activa { get; set; }

    public virtual Ciudades Ciudad { get; set; } = null!;

    public virtual ICollection<Empleado> Empleados { get; set; } = new List<Empleado>();

    public virtual ICollection<Renta> RentaSucursalDevolucions { get; set; } = new List<Renta>();

    public virtual ICollection<Renta> RentaSucursalRecogida { get; set; } = new List<Renta>();

    public virtual ICollection<Reservas> ReservaSucursalDevolucions { get; set; } = new List<Reservas>();

    public virtual ICollection<Reservas> ReservaSucursalRecogida { get; set; } = new List<Reservas>();

    public virtual ICollection<Vehiculo> Vehiculos { get; set; } = new List<Vehiculo>();
}
