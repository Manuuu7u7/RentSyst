﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class TiposMantenimiento
{
    public int TipoMantenimientoId { get; set; }

    public string Nombre { get; set; } = null!;

    public virtual ICollection<Mantenimiento> Mantenimientos { get; set; } = new List<Mantenimiento>();
}
