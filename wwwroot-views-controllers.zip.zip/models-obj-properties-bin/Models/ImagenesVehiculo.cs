﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class ImagenesVehiculo
{
    public int ImagenId { get; set; }

    public int VehiculoId { get; set; }

    public string UrlImagen { get; set; } = null!;

    public bool? EsPrincipal { get; set; }

    public virtual Vehiculo Vehiculo { get; set; } = null!;
}
