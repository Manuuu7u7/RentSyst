﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Bitacora
{
    public long BitacoraId { get; set; }

    public int? UsuarioId { get; set; }

    public DateTime FechaHora { get; set; }

    public string TipoAccion { get; set; } = null!;

    public string NombreTabla { get; set; } = null!;

    public string? Detalles { get; set; }

    public virtual Usuario? Usuario { get; set; }
}
