﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Pago
{
    public int PagoId { get; set; }

    public int RentaId { get; set; }

    public int MetodoPagoId { get; set; }

    public int? PromocionId { get; set; }

    public decimal Monto { get; set; }

    public DateTime FechaPago { get; set; }

    public string? NumeroTransaccion { get; set; }

    public string? Concepto { get; set; }

    public virtual MetodosPago MetodoPago { get; set; } = null!;

    public virtual ICollection<Multa> Multa { get; set; } = new List<Multa>();

    public virtual Promociones? Promocion { get; set; }

    public virtual Renta Renta { get; set; } = null!;
}
