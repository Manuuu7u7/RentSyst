﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Renta
{
    public int RentaId { get; set; }

    public int? ReservaId { get; set; }

    public int ClienteId { get; set; }

    public int VehiculoId { get; set; }

    public int EmpleadoEntregaId { get; set; }

    public int? EmpleadoRecepcionId { get; set; }

    public int SucursalRecogidaId { get; set; }

    public int? SucursalDevolucionId { get; set; }

    public DateTime FechaHoraRecogida { get; set; }

    public DateTime FechaHoraDevolucionPrevista { get; set; }

    public DateTime? FechaHoraDevolucionReal { get; set; }

    public int KilometrajeSalida { get; set; }

    public int? KilometrajeEntrada { get; set; }

    public string? NivelCombustibleSalida { get; set; }

    public string? NivelCombustibleEntrada { get; set; }

    public int PlanTarifaId { get; set; }

    public decimal? CostoTotalEstimado { get; set; }

    public virtual Cliente Cliente { get; set; } = null!;

    public virtual ICollection<Comentario> Comentarios { get; set; } = new List<Comentario>();

    public virtual Empleado EmpleadoEntrega { get; set; } = null!;

    public virtual Empleado? EmpleadoRecepcion { get; set; }

    public virtual ICollection<Multa> Multa { get; set; } = new List<Multa>();

    public virtual ICollection<Pago> Pagos { get; set; } = new List<Pago>();

    public virtual PlanesTarifa PlanTarifa { get; set; } = null!;

    public virtual ICollection<ReportesDanio> ReportesDanios { get; set; } = new List<ReportesDanio>();

    public virtual Reservas? Reserva { get; set; }

    public virtual Sucursales? SucursalDevolucion { get; set; }

    public virtual Sucursales SucursalRecogida { get; set; } = null!;

    public virtual Vehiculo Vehiculo { get; set; } = null!;

    public virtual ICollection<Seguro> Seguros { get; set; } = new List<Seguro>();
}
