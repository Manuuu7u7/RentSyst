﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Mantenimiento
{
    public int MantenimientoId { get; set; }

    public int VehiculoId { get; set; }

    public int TipoMantenimientoId { get; set; }

    public DateTime FechaInicio { get; set; }

    public DateTime? FechaFin { get; set; }

    public decimal? Costo { get; set; }

    public string? Taller { get; set; }

    public string Descripcion { get; set; } = null!;

    public int? RealizadoPorEmpleadoId { get; set; }

    public virtual Empleado? RealizadoPorEmpleado { get; set; }

    public virtual TiposMantenimiento TipoMantenimiento { get; set; } = null!;

    public virtual Vehiculo Vehiculo { get; set; } = null!;
}
