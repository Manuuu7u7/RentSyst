﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Comentario
{
    public int ComentarioId { get; set; }

    public int RentaId { get; set; }

    public int ClienteId { get; set; }

    public int Calificacion { get; set; }

    public string? TextoComentario { get; set; }

    public DateTime FechaComentario { get; set; }

    public bool EsPublico { get; set; }

    public virtual Cliente Cliente { get; set; } = null!;

    public virtual Renta Renta { get; set; } = null!;
}
