﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Empleado
{
    public int EmpleadoId { get; set; }

    public string Nombres { get; set; } = null!;

    public string Apellidos { get; set; } = null!;

    public string NumeroDocumento { get; set; } = null!;

    public DateOnly FechaNacimiento { get; set; }

    public int CargoId { get; set; }

    public int SucursalId { get; set; }

    public DateOnly FechaContratacion { get; set; }

    public decimal Salario { get; set; }

    public bool Activo { get; set; }

    public virtual Cargo Cargo { get; set; } = null!;

    public virtual ICollection<Mantenimiento> Mantenimientos { get; set; } = new List<Mantenimiento>();

    public virtual ICollection<Renta> RentaEmpleadoEntregas { get; set; } = new List<Renta>();

    public virtual ICollection<Renta> RentaEmpleadoRecepcions { get; set; } = new List<Renta>();

    public virtual ICollection<ReportesDanio> ReportesDanios { get; set; } = new List<ReportesDanio>();

    public virtual Sucursales Sucursal { get; set; } = null!;

    public virtual Usuario? Usuario { get; set; }
}
