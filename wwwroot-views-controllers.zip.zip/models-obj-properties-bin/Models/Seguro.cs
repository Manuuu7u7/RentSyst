﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Seguro
{
    public int SeguroId { get; set; }

    public string NombreSeguro { get; set; } = null!;

    public string Cobertura { get; set; } = null!;

    public decimal CostoDiario { get; set; }

    public virtual ICollection<Renta> Renta { get; set; } = new List<Renta>();
}
