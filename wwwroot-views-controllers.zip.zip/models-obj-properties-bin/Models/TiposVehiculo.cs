﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class TiposVehiculo
{
    public int TipoVehiculoId { get; set; }

    public string NombreTipo { get; set; } = null!;

    public string? Descripcion { get; set; }

    public virtual ICollection<PlanesTarifa> PlanesTarifas { get; set; } = new List<PlanesTarifa>();

    public virtual ICollection<Reservas> Reservas { get; set; } = new List<Reservas>();

    public virtual ICollection<Vehiculo> Vehiculos { get; set; } = new List<Vehiculo>();
}
