﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class ReportesDanio
{
    public int ReporteDanioId { get; set; }

    public int VehiculoId { get; set; }

    public int? RentaId { get; set; }

    public string Descripcion { get; set; } = null!;

    public DateTime FechaReporte { get; set; }

    public decimal? CostoEstimadoReparacion { get; set; }

    public int ReportadoPorEmpleadoId { get; set; }

    public virtual Renta? Renta { get; set; }

    public virtual Empleado ReportadoPorEmpleado { get; set; } = null!;

    public virtual Vehiculo Vehiculo { get; set; } = null!;
}
