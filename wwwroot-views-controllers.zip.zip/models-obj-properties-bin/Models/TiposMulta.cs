﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class TiposMulta
{
    public int TipoMultaId { get; set; }

    public string NombreMulta { get; set; } = null!;

    public decimal? MontoSugerido { get; set; }

    public virtual ICollection<Multa> Multa { get; set; } = new List<Multa>();
}
