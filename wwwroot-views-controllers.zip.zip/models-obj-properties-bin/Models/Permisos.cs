﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Permisos
{
    public int PermisoId { get; set; }

    public string NombrePermiso { get; set; } = null!;

    public string? Descripcion { get; set; }

    public virtual ICollection<Roles> Roles { get; set; } = new List<Roles>();
}
