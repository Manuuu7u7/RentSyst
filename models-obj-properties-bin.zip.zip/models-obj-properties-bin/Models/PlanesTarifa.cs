﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class PlanesTarifa
{
    public int PlanTarifaId { get; set; }

    public string NombrePlan { get; set; } = null!;

    public int TipoVehiculoId { get; set; }

    public decimal TarifaDiaria { get; set; }

    public decimal? TarifaSemanal { get; set; }

    public decimal? TarifaMensual { get; set; }

    public int? KilometrosIncluidos { get; set; }

    public decimal? CostoPorKmExtra { get; set; }

    public virtual ICollection<Renta> Renta { get; set; } = new List<Renta>();

    public virtual TiposVehiculo TipoVehiculo { get; set; } = null!;
}
