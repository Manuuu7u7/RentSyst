﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Roles
{
    public int RoleId { get; set; }

    public string NombreRol { get; set; } = null!;

    public virtual ICollection<Usuario> Usuarios { get; set; } = new List<Usuario>();

    public virtual ICollection<Permisos> Permisos { get; set; } = new List<Permisos>();
}
