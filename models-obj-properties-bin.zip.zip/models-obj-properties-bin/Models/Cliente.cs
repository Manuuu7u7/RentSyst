﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Cliente
{
    public int ClienteId { get; set; }

    public string Nombres { get; set; } = null!;

    public string Apellidos { get; set; } = null!;

    public string CorreoElectronico { get; set; } = null!;

    public string Telefono { get; set; } = null!;

    public DateOnly FechaNacimiento { get; set; }

    public string? Direccion { get; set; }

    public int? CiudadId { get; set; }

    public string NumeroLicencia { get; set; } = null!;

    public DateOnly FechaVencimientoLicencia { get; set; }

    public DateTime FechaRegistro { get; set; }

    public virtual Ciudades? Ciudad { get; set; }

    public virtual ICollection<ClientesCorporativo> ClientesCorporativos { get; set; } = new List<ClientesCorporativo>();

    public virtual ICollection<Comentario> Comentarios { get; set; } = new List<Comentario>();

    public virtual ICollection<Renta> Renta { get; set; } = new List<Renta>();

    public virtual ICollection<Reservas> Reservas { get; set; } = new List<Reservas>();
}
