﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Vehiculo
{
    public int VehiculoId { get; set; }

    public int ModeloId { get; set; }

    public int TipoVehiculoId { get; set; }

    public int Anio { get; set; }

    public string Vin { get; set; } = null!;

    public string Placa { get; set; } = null!;

    public string? Color { get; set; }

    public int SucursalId { get; set; }

    public int EstadoId { get; set; }

    public int Kilometraje { get; set; }

    public int? CapacidadPasajeros { get; set; }

    public string? TipoTransmision { get; set; }

    public string? TipoCombustible { get; set; }

    public DateOnly? FechaAdquisicion { get; set; }

    public bool Activo { get; set; }

    public virtual EstadosVehiculo Estado { get; set; } = null!;

    public virtual ICollection<ImagenesVehiculo> ImagenesVehiculos { get; set; } = new List<ImagenesVehiculo>();

    public virtual ICollection<Mantenimiento> Mantenimientos { get; set; } = new List<Mantenimiento>();

    public virtual Modelo Modelo { get; set; } = null!;

    public virtual ICollection<Renta> Renta { get; set; } = new List<Renta>();

    public virtual ICollection<ReportesDanio> ReportesDanios { get; set; } = new List<ReportesDanio>();

    public virtual Sucursales Sucursal { get; set; } = null!;

    public virtual TiposVehiculo TipoVehiculo { get; set; } = null!;

    public virtual ICollection<Caracteristicas> Caracteristicas { get; set; } = new List<Caracteristicas>();
}
