﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class ClientesCorporativo
{
    public int ClienteCorporativoId { get; set; }

    public int ClienteId { get; set; }

    public int CuentaCorporativaId { get; set; }

    public virtual Cliente Cliente { get; set; } = null!;

    public virtual CuentasCorporativa CuentaCorporativa { get; set; } = null!;
}
