﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Multa
{
    public int MultaId { get; set; }

    public int RentaId { get; set; }

    public int TipoMultaId { get; set; }

    public decimal Monto { get; set; }

    public DateOnly FechaEmision { get; set; }

    public bool Pagada { get; set; }

    public int? PagoId { get; set; }

    public string? Notas { get; set; }

    public virtual Pago? Pago { get; set; }

    public virtual Renta Renta { get; set; } = null!;

    public virtual TiposMulta TipoMulta { get; set; } = null!;
}
