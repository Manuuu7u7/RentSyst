﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Usuario
{
    public int UsuarioId { get; set; }

    public int? EmpleadoId { get; set; }

    public string NombreUsuario { get; set; } = null!;

    public string PasswordHash { get; set; } = null!;

    public int RoleId { get; set; }

    public DateTime FechaCreacion { get; set; }

    public DateTime? UltimoLogin { get; set; }

    public bool Activo { get; set; }

    public virtual ICollection<Bitacora> Bitacoras { get; set; } = new List<Bitacora>();

    public virtual Empleado? Empleado { get; set; }

    public virtual Roles Role { get; set; } = null!;
}
