﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class MetodosPago
{
    public int MetodoPagoId { get; set; }

    public string NombreMetodo { get; set; } = null!;

    public virtual ICollection<Pago> Pagos { get; set; } = new List<Pago>();
}
