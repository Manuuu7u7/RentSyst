﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace RentSyst.Web.Models;

public partial class RentSystContext : DbContext
{
    public RentSystContext()
    {
    }

    public RentSystContext(DbContextOptions<RentSystContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Bitacora> Bitacoras { get; set; }

    public virtual DbSet<Caracteristicas> Caracteristicas { get; set; }

    public virtual DbSet<Cargo> Cargos { get; set; }

    public virtual DbSet<Ciudades> Ciudades { get; set; }

    public virtual DbSet<Cliente> Clientes { get; set; }

    public virtual DbSet<ClientesCorporativo> ClientesCorporativos { get; set; }

    public virtual DbSet<Comentario> Comentarios { get; set; }

    public virtual DbSet<CuentasCorporativa> CuentasCorporativas { get; set; }

    public virtual DbSet<Departamentos> Departamentos { get; set; }

    public virtual DbSet<Empleado> Empleados { get; set; }

    public virtual DbSet<EstadosVehiculo> EstadosVehiculos { get; set; }

    public virtual DbSet<ImagenesVehiculo> ImagenesVehiculos { get; set; }

    public virtual DbSet<Mantenimiento> Mantenimientos { get; set; }

    public virtual DbSet<Marca> Marcas { get; set; }

    public virtual DbSet<MetodosPago> MetodosPagos { get; set; }

    public virtual DbSet<Modelo> Modelos { get; set; }

    public virtual DbSet<Multa> Multas { get; set; }

    public virtual DbSet<Pago> Pagos { get; set; }

    public virtual DbSet<Paises> Paises { get; set; }

    public virtual DbSet<Permisos> Permisos { get; set; }

    public virtual DbSet<PlanesTarifa> PlanesTarifas { get; set; }

    public virtual DbSet<Promociones> Promociones { get; set; }

    public virtual DbSet<Renta> Rentas { get; set; }

    public virtual DbSet<ReportesDanio> ReportesDanios { get; set; }

    public virtual DbSet<Reservas> Reservas { get; set; }

    public virtual DbSet<Roles> Roles { get; set; }

    public virtual DbSet<Seguro> Seguros { get; set; }

    public virtual DbSet<Sucursales> Sucursales { get; set; }

    public virtual DbSet<TiposMantenimiento> TiposMantenimientos { get; set; }

    public virtual DbSet<TiposMulta> TiposMulta { get; set; }

    public virtual DbSet<TiposVehiculo> TiposVehiculos { get; set; }

    public virtual DbSet<Usuario> Usuarios { get; set; }

    public virtual DbSet<Vehiculo> Vehiculos { get; set; }

    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Bitacora>(entity =>
        {
            entity.HasKey(e => e.BitacoraId).HasName("PK__Bitacora__7ACF9B1832F766DC");

            entity.ToTable("Bitacora");

            entity.Property(e => e.BitacoraId).HasColumnName("BitacoraID");
            entity.Property(e => e.Detalles).HasColumnType("text");
            entity.Property(e => e.FechaHora).HasDefaultValueSql("(getdate())");
            entity.Property(e => e.NombreTabla).HasMaxLength(128);
            entity.Property(e => e.TipoAccion).HasMaxLength(50);
            entity.Property(e => e.UsuarioId).HasColumnName("UsuarioID");

            entity.HasOne(d => d.Usuario).WithMany(p => p.Bitacoras)
                .HasForeignKey(d => d.UsuarioId)
                .HasConstraintName("FK__Bitacora__Usuari__607251E5");
        });

        modelBuilder.Entity<Caracteristicas>(entity =>
        {
            entity.HasKey(e => e.CaracteristicaId).HasName("PK__Caracter__E52941373DA4FA08");

            entity.HasIndex(e => e.Nombre, "UQ__Caracter__75E3EFCF6FCC693A").IsUnique();

            entity.Property(e => e.CaracteristicaId).HasColumnName("CaracteristicaID");
            entity.Property(e => e.Descripcion).HasColumnType("text");
            entity.Property(e => e.Nombre).HasMaxLength(100);
        });

        modelBuilder.Entity<Cargo>(entity =>
        {
            entity.HasKey(e => e.CargoId).HasName("PK__Cargos__B4E665ED574DCFE5");

            entity.HasIndex(e => e.NombreCargo, "UQ__Cargos__B281D7B5D30AEF0A").IsUnique();

            entity.Property(e => e.CargoId).HasColumnName("CargoID");
            entity.Property(e => e.Descripcion).HasColumnType("text");
            entity.Property(e => e.NombreCargo).HasMaxLength(100);
        });

        modelBuilder.Entity<Ciudades>(entity =>
        {
            entity.HasKey(e => e.CiudadId).HasName("PK__Ciudades__E826E7903D8A76BB");

            entity.Property(e => e.CiudadId).HasColumnName("CiudadID");
            entity.Property(e => e.DepartamentoId).HasColumnName("DepartamentoID");
            entity.Property(e => e.Nombre).HasMaxLength(100);

            entity.HasOne(d => d.Departamento).WithMany(p => p.Ciudades)
                .HasForeignKey(d => d.DepartamentoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Ciudades__Depart__5070F446");
        });

        modelBuilder.Entity<Cliente>(entity =>
        {
            entity.HasKey(e => e.ClienteId).HasName("PK__Clientes__71ABD0A77FB98711");

            entity.HasIndex(e => e.CorreoElectronico, "UQ__Clientes__531402F322B995B5").IsUnique();

            entity.HasIndex(e => e.NumeroLicencia, "UQ__Clientes__8DD65A06719D717D").IsUnique();

            entity.Property(e => e.ClienteId).HasColumnName("ClienteID");
            entity.Property(e => e.Apellidos).HasMaxLength(100);
            entity.Property(e => e.CiudadId).HasColumnName("CiudadID");
            entity.Property(e => e.CorreoElectronico).HasMaxLength(100);
            entity.Property(e => e.Direccion).HasMaxLength(255);
            entity.Property(e => e.FechaRegistro).HasDefaultValueSql("(getdate())");
            entity.Property(e => e.Nombres).HasMaxLength(100);
            entity.Property(e => e.NumeroLicencia).HasMaxLength(50);
            entity.Property(e => e.Telefono).HasMaxLength(20);

            entity.HasOne(d => d.Ciudad).WithMany(p => p.Clientes)
                .HasForeignKey(d => d.CiudadId)
                .HasConstraintName("FK__Clientes__Ciudad__72C60C4A");
        });

        modelBuilder.Entity<ClientesCorporativo>(entity =>
        {
            entity.HasKey(e => e.ClienteCorporativoId).HasName("PK__Clientes__BE7919A276C89A7C");

            entity.Property(e => e.ClienteCorporativoId).HasColumnName("ClienteCorporativoID");
            entity.Property(e => e.ClienteId).HasColumnName("ClienteID");
            entity.Property(e => e.CuentaCorporativaId).HasColumnName("CuentaCorporativaID");

            entity.HasOne(d => d.Cliente).WithMany(p => p.ClientesCorporativos)
                .HasForeignKey(d => d.ClienteId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ClientesC__Clien__7A672E12");

            entity.HasOne(d => d.CuentaCorporativa).WithMany(p => p.ClientesCorporativos)
                .HasForeignKey(d => d.CuentaCorporativaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ClientesC__Cuent__7B5B524B");
        });

        modelBuilder.Entity<Comentario>(entity =>
        {
            entity.HasKey(e => e.ComentarioId).HasName("PK__Comentar__F184495813DE9A81");

            entity.Property(e => e.ComentarioId).HasColumnName("ComentarioID");
            entity.Property(e => e.ClienteId).HasColumnName("ClienteID");
            entity.Property(e => e.EsPublico).HasDefaultValue(true);
            entity.Property(e => e.FechaComentario).HasDefaultValueSql("(getdate())");
            entity.Property(e => e.RentaId).HasColumnName("RentaID");
            entity.Property(e => e.TextoComentario).HasColumnType("text");

            entity.HasOne(d => d.Cliente).WithMany(p => p.Comentarios)
                .HasForeignKey(d => d.ClienteId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Comentari__Clien__5AB9788F");

            entity.HasOne(d => d.Renta).WithMany(p => p.Comentarios)
                .HasForeignKey(d => d.RentaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Comentari__Renta__59C55456");
        });

        modelBuilder.Entity<CuentasCorporativa>(entity =>
        {
            entity.HasKey(e => e.CuentaCorporativaId).HasName("PK__CuentasC__D50D697A7807D95C");

            entity.HasIndex(e => e.NumeroIdentificacionTributaria, "UQ__CuentasC__BF7C462D28109219").IsUnique();

            entity.Property(e => e.CuentaCorporativaId).HasColumnName("CuentaCorporativaID");
            entity.Property(e => e.CorreoContacto).HasMaxLength(100);
            entity.Property(e => e.DescuentoAplicado)
                .HasDefaultValue(0m)
                .HasColumnType("decimal(5, 2)");
            entity.Property(e => e.NombreEmpresa).HasMaxLength(200);
            entity.Property(e => e.NumeroIdentificacionTributaria).HasMaxLength(50);
            entity.Property(e => e.PersonaContacto).HasMaxLength(150);
        });

        modelBuilder.Entity<Departamentos>(entity =>
        {
            entity.HasKey(e => e.DepartamentoId).HasName("PK__Departam__66BB0E1E7AC939D2");

            entity.Property(e => e.DepartamentoId).HasColumnName("DepartamentoID");
            entity.Property(e => e.Nombre).HasMaxLength(100);
            entity.Property(e => e.PaisId).HasColumnName("PaisID");

            entity.HasOne(d => d.Pais).WithMany(p => p.Departamentos)
                .HasForeignKey(d => d.PaisId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Departame__PaisI__4D94879B");
        });

        modelBuilder.Entity<Empleado>(entity =>
        {
            entity.HasKey(e => e.EmpleadoId).HasName("PK__Empleado__958BE6F03EEB7551");

            entity.HasIndex(e => e.NumeroDocumento, "UQ__Empleado__A4202588A7A2AE84").IsUnique();

            entity.Property(e => e.EmpleadoId).HasColumnName("EmpleadoID");
            entity.Property(e => e.Activo).HasDefaultValue(true);
            entity.Property(e => e.Apellidos).HasMaxLength(100);
            entity.Property(e => e.CargoId).HasColumnName("CargoID");
            entity.Property(e => e.Nombres).HasMaxLength(100);
            entity.Property(e => e.NumeroDocumento).HasMaxLength(50);
            entity.Property(e => e.Salario).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.SucursalId).HasColumnName("SucursalID");

            entity.HasOne(d => d.Cargo).WithMany(p => p.Empleados)
                .HasForeignKey(d => d.CargoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Empleados__Cargo__5AEE82B9");

            entity.HasOne(d => d.Sucursal).WithMany(p => p.Empleados)
                .HasForeignKey(d => d.SucursalId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Empleados__Sucur__5BE2A6F2");
        });

        modelBuilder.Entity<EstadosVehiculo>(entity =>
        {
            entity.HasKey(e => e.EstadoId).HasName("PK__EstadosV__FEF86B607DEFC6B3");

            entity.ToTable("EstadosVehiculo");

            entity.HasIndex(e => e.NombreEstado, "UQ__EstadosV__6CE50615E819180A").IsUnique();

            entity.Property(e => e.EstadoId).HasColumnName("EstadoID");
            entity.Property(e => e.NombreEstado).HasMaxLength(50);
        });

        modelBuilder.Entity<ImagenesVehiculo>(entity =>
        {
            entity.HasKey(e => e.ImagenId).HasName("PK__Imagenes__0C7D20D72843A7F0");

            entity.Property(e => e.ImagenId).HasColumnName("ImagenID");
            entity.Property(e => e.EsPrincipal).HasDefaultValue(false);
            entity.Property(e => e.UrlImagen)
                .HasMaxLength(512)
                .HasColumnName("URL_Imagen");
            entity.Property(e => e.VehiculoId).HasColumnName("VehiculoID");

            entity.HasOne(d => d.Vehiculo).WithMany(p => p.ImagenesVehiculos)
                .HasForeignKey(d => d.VehiculoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ImagenesV__Vehic__17F790F9");
        });

        modelBuilder.Entity<Mantenimiento>(entity =>
        {
            entity.HasKey(e => e.MantenimientoId).HasName("PK__Mantenim__A62E6142D48474DF");

            entity.Property(e => e.MantenimientoId).HasColumnName("MantenimientoID");
            entity.Property(e => e.Costo).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.Descripcion).HasColumnType("text");
            entity.Property(e => e.RealizadoPorEmpleadoId).HasColumnName("RealizadoPor_EmpleadoID");
            entity.Property(e => e.Taller).HasMaxLength(200);
            entity.Property(e => e.TipoMantenimientoId).HasColumnName("TipoMantenimientoID");
            entity.Property(e => e.VehiculoId).HasColumnName("VehiculoID");

            entity.HasOne(d => d.RealizadoPorEmpleado).WithMany(p => p.Mantenimientos)
                .HasForeignKey(d => d.RealizadoPorEmpleadoId)
                .HasConstraintName("FK__Mantenimi__Reali__208CD6FA");

            entity.HasOne(d => d.TipoMantenimiento).WithMany(p => p.Mantenimientos)
                .HasForeignKey(d => d.TipoMantenimientoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Mantenimi__TipoM__1F98B2C1");

            entity.HasOne(d => d.Vehiculo).WithMany(p => p.Mantenimientos)
                .HasForeignKey(d => d.VehiculoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Mantenimi__Vehic__1EA48E88");
        });

        modelBuilder.Entity<Marca>(entity =>
        {
            entity.HasKey(e => e.MarcaId).HasName("PK__Marcas__D5B1CDEB0BB94473");

            entity.HasIndex(e => e.Nombre, "UQ__Marcas__75E3EFCF71FF16AE").IsUnique();

            entity.Property(e => e.MarcaId).HasColumnName("MarcaID");
            entity.Property(e => e.Nombre).HasMaxLength(100);
        });

        modelBuilder.Entity<MetodosPago>(entity =>
        {
            entity.HasKey(e => e.MetodoPagoId).HasName("PK__MetodosP__A8FEAF74C70BBC79");

            entity.ToTable("MetodosPago");

            entity.HasIndex(e => e.NombreMetodo, "UQ__MetodosP__EDA0070FEDCA6670").IsUnique();

            entity.Property(e => e.MetodoPagoId).HasColumnName("MetodoPagoID");
            entity.Property(e => e.NombreMetodo).HasMaxLength(50);
        });

        modelBuilder.Entity<Modelo>(entity =>
        {
            entity.HasKey(e => e.ModeloId).HasName("PK__Modelos__FA6052BA9BB7654D");

            entity.Property(e => e.ModeloId).HasColumnName("ModeloID");
            entity.Property(e => e.MarcaId).HasColumnName("MarcaID");
            entity.Property(e => e.Nombre).HasMaxLength(100);

            entity.HasOne(d => d.Marca).WithMany(p => p.Modelos)
                .HasForeignKey(d => d.MarcaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Modelos__MarcaID__01142BA1");
        });

        modelBuilder.Entity<Multa>(entity =>
        {
            entity.HasKey(e => e.MultaId).HasName("PK__Multas__DA090D80C95DA8E2");

            entity.Property(e => e.MultaId).HasColumnName("MultaID");
            entity.Property(e => e.Monto).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.Notas).HasColumnType("text");
            entity.Property(e => e.PagoId).HasColumnName("PagoID");
            entity.Property(e => e.RentaId).HasColumnName("RentaID");
            entity.Property(e => e.TipoMultaId).HasColumnName("TipoMultaID");

            entity.HasOne(d => d.Pago).WithMany(p => p.Multa)
                .HasForeignKey(d => d.PagoId)
                .HasConstraintName("FK__Multas__PagoID__56E8E7AB");

            entity.HasOne(d => d.Renta).WithMany(p => p.Multa)
                .HasForeignKey(d => d.RentaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Multas__RentaID__540C7B00");

            entity.HasOne(d => d.TipoMulta).WithMany(p => p.Multa)
                .HasForeignKey(d => d.TipoMultaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Multas__TipoMult__55009F39");
        });

        modelBuilder.Entity<Pago>(entity =>
        {
            entity.HasKey(e => e.PagoId).HasName("PK__Pagos__F00B61583F5D2B6A");

            entity.Property(e => e.PagoId).HasColumnName("PagoID");
            entity.Property(e => e.Concepto).HasMaxLength(150);
            entity.Property(e => e.FechaPago).HasDefaultValueSql("(getdate())");
            entity.Property(e => e.MetodoPagoId).HasColumnName("MetodoPagoID");
            entity.Property(e => e.Monto).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.NumeroTransaccion).HasMaxLength(255);
            entity.Property(e => e.PromocionId).HasColumnName("PromocionID");
            entity.Property(e => e.RentaId).HasColumnName("RentaID");

            entity.HasOne(d => d.MetodoPago).WithMany(p => p.Pagos)
                .HasForeignKey(d => d.MetodoPagoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Pagos__MetodoPag__4C6B5938");

            entity.HasOne(d => d.Promocion).WithMany(p => p.Pagos)
                .HasForeignKey(d => d.PromocionId)
                .HasConstraintName("FK__Pagos__Promocion__4D5F7D71");

            entity.HasOne(d => d.Renta).WithMany(p => p.Pagos)
                .HasForeignKey(d => d.RentaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Pagos__RentaID__4B7734FF");
        });

        modelBuilder.Entity<Paises>(entity =>
        {
            entity.HasKey(e => e.PaisId).HasName("PK__Paises__B501E1A5D74E586E");

            entity.HasIndex(e => e.Nombre, "UQ__Paises__75E3EFCF5D45C251").IsUnique();

            entity.HasIndex(e => e.CodigoIso, "UQ__Paises__F2D69746FEC80FD6").IsUnique();

            entity.Property(e => e.PaisId).HasColumnName("PaisID");
            entity.Property(e => e.CodigoIso)
                .HasMaxLength(2)
                .IsUnicode(false)
                .IsFixedLength()
                .HasColumnName("CodigoISO");
            entity.Property(e => e.Nombre).HasMaxLength(100);
        });

        modelBuilder.Entity<Permisos>(entity =>
        {
            entity.HasKey(e => e.PermisoId).HasName("PK__Permisos__96E0C703C221D57B");

            entity.HasIndex(e => e.NombrePermiso, "UQ__Permisos__BA19B18D665A6F4D").IsUnique();

            entity.Property(e => e.PermisoId).HasColumnName("PermisoID");
            entity.Property(e => e.Descripcion).HasMaxLength(255);
            entity.Property(e => e.NombrePermiso).HasMaxLength(100);
        });

        modelBuilder.Entity<PlanesTarifa>(entity =>
        {
            entity.HasKey(e => e.PlanTarifaId).HasName("PK__PlanesTa__52E300C5CC0CA15C");

            entity.ToTable("PlanesTarifa");

            entity.Property(e => e.PlanTarifaId).HasColumnName("PlanTarifaID");
            entity.Property(e => e.CostoPorKmExtra).HasColumnType("decimal(8, 2)");
            entity.Property(e => e.KilometrosIncluidos).HasDefaultValue(0);
            entity.Property(e => e.NombrePlan).HasMaxLength(100);
            entity.Property(e => e.TarifaDiaria).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.TarifaMensual).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.TarifaSemanal).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.TipoVehiculoId).HasColumnName("TipoVehiculoID");

            entity.HasOne(d => d.TipoVehiculo).WithMany(p => p.PlanesTarifas)
                .HasForeignKey(d => d.TipoVehiculoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__PlanesTar__TipoV__282DF8C2");
        });

        modelBuilder.Entity<Promociones>(entity =>
        {
            entity.HasKey(e => e.PromocionId).HasName("PK__Promocio__2DA61DBD27C07608");

            entity.HasIndex(e => e.CodigoPromocion, "UQ__Promocio__6121574BF964EC07").IsUnique();

            entity.Property(e => e.PromocionId).HasColumnName("PromocionID");
            entity.Property(e => e.Activa).HasDefaultValue(true);
            entity.Property(e => e.CodigoPromocion).HasMaxLength(20);
            entity.Property(e => e.Descripcion).HasColumnType("text");
            entity.Property(e => e.PorcentajeDescuento).HasColumnType("decimal(5, 2)");
        });

        modelBuilder.Entity<Renta>(entity =>
        {
            entity.HasKey(e => e.RentaId).HasName("PK__Rentas__3440A363C206A31D");

            entity.HasIndex(e => e.ReservaId, "UQ__Rentas__C399370267B9A3B8").IsUnique();

            entity.Property(e => e.RentaId).HasColumnName("RentaID");
            entity.Property(e => e.ClienteId).HasColumnName("ClienteID");
            entity.Property(e => e.CostoTotalEstimado).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.EmpleadoEntregaId).HasColumnName("EmpleadoEntregaID");
            entity.Property(e => e.EmpleadoRecepcionId).HasColumnName("EmpleadoRecepcionID");
            entity.Property(e => e.NivelCombustibleEntrada).HasMaxLength(20);
            entity.Property(e => e.NivelCombustibleSalida).HasMaxLength(20);
            entity.Property(e => e.PlanTarifaId).HasColumnName("PlanTarifaID");
            entity.Property(e => e.ReservaId).HasColumnName("ReservaID");
            entity.Property(e => e.SucursalDevolucionId).HasColumnName("SucursalDevolucionID");
            entity.Property(e => e.SucursalRecogidaId).HasColumnName("SucursalRecogidaID");
            entity.Property(e => e.VehiculoId).HasColumnName("VehiculoID");

            entity.HasOne(d => d.Cliente).WithMany(p => p.Renta)
                .HasForeignKey(d => d.ClienteId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Rentas__ClienteI__37703C52");

            entity.HasOne(d => d.EmpleadoEntrega).WithMany(p => p.RentaEmpleadoEntregas)
                .HasForeignKey(d => d.EmpleadoEntregaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Rentas__Empleado__395884C4");

            entity.HasOne(d => d.EmpleadoRecepcion).WithMany(p => p.RentaEmpleadoRecepcions)
                .HasForeignKey(d => d.EmpleadoRecepcionId)
                .HasConstraintName("FK__Rentas__Empleado__3A4CA8FD");

            entity.HasOne(d => d.PlanTarifa).WithMany(p => p.Renta)
                .HasForeignKey(d => d.PlanTarifaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Rentas__PlanTari__3D2915A8");

            entity.HasOne(d => d.Reserva).WithOne(p => p.Renta)
                .HasForeignKey<Renta>(d => d.ReservaId)
                .HasConstraintName("FK__Rentas__ReservaI__367C1819");

            entity.HasOne(d => d.SucursalDevolucion).WithMany(p => p.RentaSucursalDevolucions)
                .HasForeignKey(d => d.SucursalDevolucionId)
                .HasConstraintName("FK__Rentas__Sucursal__3C34F16F");

            entity.HasOne(d => d.SucursalRecogida).WithMany(p => p.RentaSucursalRecogida)
                .HasForeignKey(d => d.SucursalRecogidaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Rentas__Sucursal__3B40CD36");

            entity.HasOne(d => d.Vehiculo).WithMany(p => p.Renta)
                .HasForeignKey(d => d.VehiculoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Rentas__Vehiculo__3864608B");

            entity.HasMany(d => d.Seguros).WithMany(p => p.Renta)
                .UsingEntity<Dictionary<string, object>>(
                    "RentasSeguro",
                    r => r.HasOne<Seguro>().WithMany()
                        .HasForeignKey("SeguroId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__RentasSeg__Segur__41EDCAC5"),
                    l => l.HasOne<Renta>().WithMany()
                        .HasForeignKey("RentaId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__RentasSeg__Renta__40F9A68C"),
                    j =>
                    {
                        j.HasKey("RentaId", "SeguroId").HasName("PK__RentasSe__8CF8DE61C1448BF3");
                        j.ToTable("RentasSeguros");
                        j.IndexerProperty<int>("RentaId").HasColumnName("RentaID");
                        j.IndexerProperty<int>("SeguroId").HasColumnName("SeguroID");
                    });
        });

        modelBuilder.Entity<ReportesDanio>(entity =>
        {
            entity.HasKey(e => e.ReporteDanioId).HasName("PK__Reportes__DDAD073416F236C2");

            entity.Property(e => e.ReporteDanioId).HasColumnName("ReporteDanioID");
            entity.Property(e => e.CostoEstimadoReparacion).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.Descripcion).HasColumnType("text");
            entity.Property(e => e.FechaReporte).HasDefaultValueSql("(getdate())");
            entity.Property(e => e.RentaId).HasColumnName("RentaID");
            entity.Property(e => e.ReportadoPorEmpleadoId).HasColumnName("ReportadoPor_EmpleadoID");
            entity.Property(e => e.VehiculoId).HasColumnName("VehiculoID");

            entity.HasOne(d => d.Renta).WithMany(p => p.ReportesDanios)
                .HasForeignKey(d => d.RentaId)
                .HasConstraintName("FK__ReportesD__Renta__3E1D39E1");

            entity.HasOne(d => d.ReportadoPorEmpleado).WithMany(p => p.ReportesDanios)
                .HasForeignKey(d => d.ReportadoPorEmpleadoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ReportesD__Repor__25518C17");

            entity.HasOne(d => d.Vehiculo).WithMany(p => p.ReportesDanios)
                .HasForeignKey(d => d.VehiculoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ReportesD__Vehic__236943A5");
        });

        modelBuilder.Entity<Reservas>(entity =>
        {
            entity.HasKey(e => e.ReservaId).HasName("PK__Reservas__C399370373C3D240");

            entity.Property(e => e.ReservaId).HasColumnName("ReservaID");
            entity.Property(e => e.ClienteId).HasColumnName("ClienteID");
            entity.Property(e => e.EstadoReserva)
                .HasMaxLength(20)
                .HasDefaultValue("Confirmada");
            entity.Property(e => e.FechaCreacion).HasDefaultValueSql("(getdate())");
            entity.Property(e => e.SucursalDevolucionId).HasColumnName("SucursalDevolucionID");
            entity.Property(e => e.SucursalRecogidaId).HasColumnName("SucursalRecogidaID");
            entity.Property(e => e.TipoVehiculoId).HasColumnName("TipoVehiculoID");

            entity.HasOne(d => d.Cliente).WithMany(p => p.Reservas)
                .HasForeignKey(d => d.ClienteId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reservas__Client__2DE6D218");

            entity.HasOne(d => d.SucursalDevolucion).WithMany(p => p.ReservaSucursalDevolucions)
                .HasForeignKey(d => d.SucursalDevolucionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reservas__Sucurs__30C33EC3");

            entity.HasOne(d => d.SucursalRecogida).WithMany(p => p.ReservaSucursalRecogida)
                .HasForeignKey(d => d.SucursalRecogidaId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reservas__Sucurs__2FCF1A8A");

            entity.HasOne(d => d.TipoVehiculo).WithMany(p => p.Reservas)
                .HasForeignKey(d => d.TipoVehiculoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reservas__TipoVe__2EDAF651");
        });

        modelBuilder.Entity<Roles>(entity =>
        {
            entity.HasKey(e => e.RoleId).HasName("PK__Roles__8AFACE3AAD7928AD");

            entity.HasIndex(e => e.NombreRol, "UQ__Roles__4F0B537F247A2AC8").IsUnique();

            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.NombreRol).HasMaxLength(50);

            entity.HasMany(d => d.Permisos).WithMany(p => p.Roles)
                .UsingEntity<Dictionary<string, object>>(
                    "RolesPermiso",
                    r => r.HasOne<Permisos>().WithMany()
                        .HasForeignKey("PermisoId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__RolesPerm__Permi__66603565"),
                    l => l.HasOne<Roles>().WithMany()
                        .HasForeignKey("RoleId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__RolesPerm__RoleI__656C112C"),
                    j =>
                    {
                        j.HasKey("RoleId", "PermisoId").HasName("PK__RolesPer__A394C24A1F92956F");
                        j.ToTable("RolesPermisos");
                        j.IndexerProperty<int>("RoleId").HasColumnName("RoleID");
                        j.IndexerProperty<int>("PermisoId").HasColumnName("PermisoID");
                    });
        });

        modelBuilder.Entity<Seguro>(entity =>
        {
            entity.HasKey(e => e.SeguroId).HasName("PK__Seguros__8B87D02AE3D55464");

            entity.Property(e => e.SeguroId).HasColumnName("SeguroID");
            entity.Property(e => e.Cobertura).HasColumnType("text");
            entity.Property(e => e.CostoDiario).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.NombreSeguro).HasMaxLength(100);
        });

        modelBuilder.Entity<Sucursales>(entity =>
        {
            entity.HasKey(e => e.SucursalId).HasName("PK__Sucursal__6CB482812EFA5DCC");

            entity.Property(e => e.SucursalId).HasColumnName("SucursalID");
            entity.Property(e => e.Activa).HasDefaultValue(true);
            entity.Property(e => e.CiudadId).HasColumnName("CiudadID");
            entity.Property(e => e.CorreoElectronico).HasMaxLength(100);
            entity.Property(e => e.Direccion).HasMaxLength(255);
            entity.Property(e => e.Nombre).HasMaxLength(150);
            entity.Property(e => e.Telefono).HasMaxLength(20);

            entity.HasOne(d => d.Ciudad).WithMany(p => p.Sucursales)
                .HasForeignKey(d => d.CiudadId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Sucursale__Ciuda__534D60F1");
        });

        modelBuilder.Entity<TiposMantenimiento>(entity =>
        {
            entity.HasKey(e => e.TipoMantenimientoId).HasName("PK__TiposMan__CF3911E71A2F5AC7");

            entity.ToTable("TiposMantenimiento");

            entity.HasIndex(e => e.Nombre, "UQ__TiposMan__75E3EFCFA2051D22").IsUnique();

            entity.Property(e => e.TipoMantenimientoId).HasColumnName("TipoMantenimientoID");
            entity.Property(e => e.Nombre).HasMaxLength(100);
        });

        modelBuilder.Entity<TiposMulta>(entity =>
        {
            entity.HasKey(e => e.TipoMultaId).HasName("PK__TiposMul__5EF222A07B2F674D");

            entity.HasIndex(e => e.NombreMulta, "UQ__TiposMul__184C789E80021466").IsUnique();

            entity.Property(e => e.TipoMultaId).HasColumnName("TipoMultaID");
            entity.Property(e => e.MontoSugerido).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.NombreMulta).HasMaxLength(100);
        });

        modelBuilder.Entity<TiposVehiculo>(entity =>
        {
            entity.HasKey(e => e.TipoVehiculoId).HasName("PK__TiposVeh__1EA21D2DEF0A5389");

            entity.ToTable("TiposVehiculo");

            entity.Property(e => e.TipoVehiculoId).HasColumnName("TipoVehiculoID");
            entity.Property(e => e.Descripcion).HasColumnType("text");
            entity.Property(e => e.NombreTipo).HasMaxLength(100);
        });

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.HasKey(e => e.UsuarioId).HasName("PK__Usuarios__2B3DE79894938B14");

            entity.HasIndex(e => e.NombreUsuario, "UQ__Usuarios__6B0F5AE01F2F3F9D").IsUnique();

            entity.HasIndex(e => e.EmpleadoId, "UQ__Usuarios__958BE6F13F059363").IsUnique();

            entity.Property(e => e.UsuarioId).HasColumnName("UsuarioID");
            entity.Property(e => e.Activo).HasDefaultValue(true);
            entity.Property(e => e.EmpleadoId).HasColumnName("EmpleadoID");
            entity.Property(e => e.FechaCreacion).HasDefaultValueSql("(getdate())");
            entity.Property(e => e.NombreUsuario).HasMaxLength(50);
            entity.Property(e => e.PasswordHash).HasMaxLength(256);
            entity.Property(e => e.RoleId).HasColumnName("RoleID");

            entity.HasOne(d => d.Empleado).WithOne(p => p.Usuario)
                .HasForeignKey<Usuario>(d => d.EmpleadoId)
                .HasConstraintName("FK__Usuarios__Emplea__6B24EA82");

            entity.HasOne(d => d.Role).WithMany(p => p.Usuarios)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Usuarios__RoleID__6C190EBB");
        });

        modelBuilder.Entity<Vehiculo>(entity =>
        {
            entity.HasKey(e => e.VehiculoId).HasName("PK__Vehiculo__AA088620B36CD850");

            entity.HasIndex(e => e.Placa, "UQ__Vehiculo__8310F99D2988EF0F").IsUnique();

            entity.HasIndex(e => e.Vin, "UQ__Vehiculo__C5DF234CF9B9C5CF").IsUnique();

            entity.Property(e => e.VehiculoId).HasColumnName("VehiculoID");
            entity.Property(e => e.Activo).HasDefaultValue(true);
            entity.Property(e => e.Color).HasMaxLength(50);
            entity.Property(e => e.EstadoId).HasColumnName("EstadoID");
            entity.Property(e => e.ModeloId).HasColumnName("ModeloID");
            entity.Property(e => e.Placa).HasMaxLength(10);
            entity.Property(e => e.SucursalId).HasColumnName("SucursalID");
            entity.Property(e => e.TipoCombustible).HasMaxLength(20);
            entity.Property(e => e.TipoTransmision).HasMaxLength(20);
            entity.Property(e => e.TipoVehiculoId).HasColumnName("TipoVehiculoID");
            entity.Property(e => e.Vin)
                .HasMaxLength(17)
                .HasColumnName("VIN");

            entity.HasOne(d => d.Estado).WithMany(p => p.Vehiculos)
                .HasForeignKey(d => d.EstadoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Vehiculos__Estad__0D7A0286");

            entity.HasOne(d => d.Modelo).WithMany(p => p.Vehiculos)
                .HasForeignKey(d => d.ModeloId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Vehiculos__Model__0A9D95DB");

            entity.HasOne(d => d.Sucursal).WithMany(p => p.Vehiculos)
                .HasForeignKey(d => d.SucursalId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Vehiculos__Sucur__0C85DE4D");

            entity.HasOne(d => d.TipoVehiculo).WithMany(p => p.Vehiculos)
                .HasForeignKey(d => d.TipoVehiculoId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Vehiculos__TipoV__0B91BA14");

            entity.HasMany(d => d.Caracteristicas).WithMany(p => p.Vehiculos)
                .UsingEntity<Dictionary<string, object>>(
                    "VehiculosCaracteristica",
                    r => r.HasOne<Caracteristicas>().WithMany()
                        .HasForeignKey("CaracteristicaId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__Vehiculos__Carac__151B244E"),
                    l => l.HasOne<Vehiculo>().WithMany()
                        .HasForeignKey("VehiculoId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__Vehiculos__Vehic__14270015"),
                    j =>
                    {
                        j.HasKey("VehiculoId", "CaracteristicaId").HasName("PK__Vehiculo__C45A1233135B78F0");
                        j.ToTable("VehiculosCaracteristicas");
                        j.IndexerProperty<int>("VehiculoId").HasColumnName("VehiculoID");
                        j.IndexerProperty<int>("CaracteristicaId").HasColumnName("CaracteristicaID");
                    });
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
