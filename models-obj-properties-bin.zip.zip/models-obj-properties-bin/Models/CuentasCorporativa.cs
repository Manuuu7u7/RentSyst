﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class CuentasCorporativa
{
    public int CuentaCorporativaId { get; set; }

    public string NombreEmpresa { get; set; } = null!;

    public string NumeroIdentificacionTributaria { get; set; } = null!;

    public string? PersonaContacto { get; set; }

    public string? CorreoContacto { get; set; }

    public decimal? DescuentoAplicado { get; set; }

    public virtual ICollection<ClientesCorporativo> ClientesCorporativos { get; set; } = new List<ClientesCorporativo>();
}
