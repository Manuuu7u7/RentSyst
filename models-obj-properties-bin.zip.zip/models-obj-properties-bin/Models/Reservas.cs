﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Reservas
{
    public int ReservaId { get; set; }

    public int ClienteId { get; set; }

    public int TipoVehiculoId { get; set; }

    public int SucursalRecogidaId { get; set; }

    public int SucursalDevolucionId { get; set; }

    public DateTime FechaHoraRecogida { get; set; }

    public DateTime FechaHoraDevolucion { get; set; }

    public DateTime FechaCreacion { get; set; }

    public string EstadoReserva { get; set; } = null!;

    public virtual Cliente Cliente { get; set; } = null!;

    public virtual Renta? Renta { get; set; }

    public virtual Sucursales SucursalDevolucion { get; set; } = null!;

    public virtual Sucursales SucursalRecogida { get; set; } = null!;

    public virtual TiposVehiculo TipoVehiculo { get; set; } = null!;
}
