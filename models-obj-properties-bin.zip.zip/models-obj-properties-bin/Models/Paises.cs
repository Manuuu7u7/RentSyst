﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Paises
{
    public int PaisId { get; set; }

    public string Nombre { get; set; } = null!;

    public string CodigoIso { get; set; } = null!;

    public virtual ICollection<Departamentos> Departamentos { get; set; } = new List<Departamentos>();
}
