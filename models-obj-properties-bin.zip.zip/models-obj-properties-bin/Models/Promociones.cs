﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Promociones
{
    public int PromocionId { get; set; }

    public string CodigoPromocion { get; set; } = null!;

    public string? Descripcion { get; set; }

    public decimal PorcentajeDescuento { get; set; }

    public DateOnly FechaInicio { get; set; }

    public DateOnly FechaFin { get; set; }

    public bool Activa { get; set; }

    public virtual ICollection<Pago> Pagos { get; set; } = new List<Pago>();
}
