﻿using System;
using System.Collections.Generic;

namespace RentSyst.Web.Models;

public partial class Departamentos
{
    public int DepartamentoId { get; set; }

    public int PaisId { get; set; }

    public string Nombre { get; set; } = null!;

    public virtual ICollection<Ciudades> Ciudades { get; set; } = new List<Ciudades>();

    public virtual Paises Pais { get; set; } = null!;
}
